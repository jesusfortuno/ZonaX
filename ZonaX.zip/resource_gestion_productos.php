<html lang="ca">

<head>
    <title>Gestión de Productos - TDIW</title>
</head>

<body>

    <div class="container">
        <?php require __DIR__ . '/controller/gestionar_productos.php'; ?>
    </div>

</body>

</html> 