<!DOCTYPE html>
<html lang="es">
<head>
    <title>Registro - TDIW</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../scripts/verificar_email.js"></script>
</head>
<body>
    <div class="container">
        <?php require __DIR__ . '/controller/almacenar_registro.php'; ?>
    </div>
</body>
</html>
