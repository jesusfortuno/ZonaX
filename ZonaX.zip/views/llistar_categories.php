<!--<ul>
    /*<?php foreach ($categories as $categoria) : ?>
        
            <h3><a href="#"><?php echo $categoria['nombre_categoria'] ?> </a></h3>
            <p><?php echo htmlspecialchars($categoria['descripcion']); ?> </p>
        
    <?php endforeach; ?>*/
</ul>-->