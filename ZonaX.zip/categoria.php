<html lang="ca">

<head>
    <title>listado de categorias - TDIW</title>
</head>

<body>

    <div class="container">
        <?php require __DIR__ . '/controller/categoria_controller.php'; ?>
    </div>

</body>

</html> 