<html lang="ca">

<head>
    <title>Llistat de categories - TDIW</title>
</head>

<body>

    <div class="container">
        <?php require __DIR__ . '/controller/categoria_controller.php'; ?>
    </div>

</body>

</html>