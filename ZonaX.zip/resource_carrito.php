<html lang="ca">

<head>
    <title>Carrito - TDIW</title>
</head>

<body>

    <div class="container">
        <?php require __DIR__ . '/controller/carrito_controller.php'; ?>
    </div>

</body>

</html> 